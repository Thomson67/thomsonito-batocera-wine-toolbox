#!/bin/bash

STARTER_DATA="$WT_ROOT/data/starter-pack.json"
RUNNERS_DATA="$WT_ROOT/data/runners.json"
STARTER_STAGE="$WT_HOME/staging/starter-pack"

starter_status_tsv() {
    python3 - "$STARTER_DATA" "$RUNNERS_DATA" <<'PY'
import json, os, sys
starter=json.load(open(sys.argv[1], encoding="utf-8"))
catalog=json.load(open(sys.argv[2], encoding="utf-8"))
byid={r["id"]:r for r in catalog["runners"]}
install_path=catalog.get("install_path","/userdata/system/wine/custom")

print("META\t"+starter["version"]+"\t"+install_path)
for rid in starter["classic_runner_ids"]:
    r=byid[rid]
    target=os.path.join(install_path, r["name"])
    state="installed" if os.path.isdir(target) else "missing"
    print("CLASSIC\t%s\t%s\t%s\t%s\t%s\t%s\t%s" % (
        rid, r["name"], state, r["file"], r["size_bytes"], r["download_url"], r["sha256"]
    ))
for rid in starter.get("umu_runner_ids", []):
    target=os.path.join("/userdata/system/wine/custom", rid)
    state="installed" if os.path.isdir(target) else "missing"
    print("UMU\t%s\t%s" % (rid, state))
PY
}

starter_summary_values() {
    starter_status_tsv | python3 -c '
import sys
classic=ci=cm=umu=ui=um=download=0
version=path=""
for raw in sys.stdin:
    p=raw.rstrip("\n").split("\t")
    if p[0]=="META":
        version,path=p[1],p[2]
    elif p[0]=="CLASSIC":
        classic+=1
        if p[3]=="installed": ci+=1
        else:
            cm+=1
            download+=int(p[5])
    elif p[0]=="UMU":
        umu+=1
        if p[2]=="installed": ui+=1
        else: um+=1
print("\t".join(map(str,[version,path,classic,ci,cm,umu,ui,um,download])))
'
}

install_classic_runner_row() {
    local name="$1" file="$2" url="$3" sha="$4" target="$BATOCERA_CUSTOM_WINE/$name"
    local stage archive extract candidate count
    [ -d "$target" ] && return 0

    stage="$(mktemp -d "$STARTER_STAGE/${name}.XXXXXX")" || return 1
    archive="$stage/$file"
    extract="$stage/extracted"
    mkdir -p "$extract"

    echo
    echo "$(i18n starter_installing_classic "$name")"
    echo "$(i18n starter_downloading "$file")"
    if ! download_file "$url" "$archive"; then
        echo "$(i18n starter_failed_download "$name")" >&2
        rm -rf "$stage"
        return 1
    fi

    echo "$(i18n starter_checksum)"
    if ! verify_sha256 "$archive" "$sha"; then
        echo "$(i18n starter_checksum_bad "$name")" >&2
        rm -rf "$stage"
        return 1
    fi
    echo "$(i18n starter_checksum_ok)"

    echo "$(i18n starter_extracting "$name")"
    if ! tar -xJf "$archive" -C "$extract"; then
        echo "$(i18n starter_failed_extract "$name")" >&2
        rm -rf "$stage"
        return 1
    fi

    if [ -d "$extract/$name" ]; then
        candidate="$extract/$name"
    else
        count="$(find "$extract" -mindepth 1 -maxdepth 1 -type d | wc -l)"
        [ "$count" -eq 1 ] || {
            echo "$(i18n starter_bad_archive "$name")" >&2
            rm -rf "$stage"
            return 1
        }
        candidate="$(find "$extract" -mindepth 1 -maxdepth 1 -type d | head -n1)"
    fi

    [ ! -e "$target" ] || {
        echo "$(i18n starter_target_exists "$target")" >&2
        rm -rf "$stage"
        return 1
    }

    mv "$candidate" "$target" || {
        rm -rf "$stage"
        return 1
    }

    rm -rf "$stage"
    echo "$(i18n starter_installed "$name")"
}

install_starter_pack() {
    local vals version install_path classic ci cm umu ui um download
    local free estimate failures=0

    vals="$(starter_summary_values)" || {
        msgbox "$(i18n starter_title)" "$(i18n starter_missing_catalog)"
        return
    }
    IFS=$'\t' read -r version install_path classic ci cm umu ui um download <<< "$vals"

    if [ "$cm" -eq 0 ] && [ "$um" -eq 0 ]; then
        msgbox "$(i18n starter_title)" "$(i18n starter_nothing)"
        return
    fi

    # Conservative workspace estimate: compressed downloads + extraction/install
    # headroom. Existing runners are not counted because they are never touched.
    estimate=$(( download * 4 + 536870912 ))
    free="$(free_bytes_userdata)"
    if [ -n "$free" ] && [ "$free" -lt "$estimate" ]; then
        msgbox "$(i18n starter_title)" \
            "$(i18n starter_space_low "$(human_bytes "$estimate")" "$(human_bytes "$free")")"
        return
    fi

    yesno "$(i18n starter_title)" "$(i18n starter_confirm "$install_path")" || return

    mkdir -p "$STARTER_STAGE" "$BATOCERA_CUSTOM_WINE"

    while IFS=$'\t' read -r kind id name state file size url sha; do
        [ "$kind" = "CLASSIC" ] || continue
        [ "$state" = "missing" ] || continue
        install_classic_runner_row "$name" "$file" "$url" "$sha" || failures=$((failures+1))
    done <<< "$(starter_status_tsv)"

    if [ "$um" -gt 0 ]; then
        echo
        echo "$(i18n starter_preparing_umu)"
        if ensure_umu_toolbox; then
            while IFS=$'\t' read -r kind id state; do
                [ "$kind" = "UMU" ] || continue
                [ "$state" = "missing" ] || continue
                if ! install_umu_runner "$id"; then
                    echo "$(i18n umu_runner_failed "$id")" >&2
                    failures=$((failures+1))
                fi
            done <<< "$(starter_status_tsv)"
        else
            failures=$((failures+um))
        fi
    fi

    if [ "$failures" -eq 0 ]; then
        msgbox "$(i18n starter_title)" "$(i18n starter_complete)"
    else
        msgbox "$(i18n starter_title)" "$(i18n starter_partial)"
    fi
}

starter_pack_menu() {
    while true; do
        local vals version install_path classic ci cm umu ui um download free estimate choice summary
        vals="$(starter_summary_values 2>/dev/null)" || {
            msgbox "$(i18n starter_title)" "$(i18n starter_missing_catalog)"
            return
        }
        IFS=$'\t' read -r version install_path classic ci cm umu ui um download <<< "$vals"
        free="$(free_bytes_userdata)"
        estimate=$(( download * 4 + 536870912 ))
        summary="$(i18n starter_summary \
            "$version" "$classic" "$ci" "$cm" \
            "$umu" "$ui" "$um" \
            "$(human_bytes "$download")" \
            "$(human_bytes "$estimate")" \
            "$(human_bytes "${free:-0}")")"

        choice="$(menu_select "$(i18n starter_title)" "$summary" \
            "1" "$(i18n starter_install)" \
            "2" "$(i18n starter_refresh)" \
            "0" "$(i18n back)")" || return

        case "$choice" in
            1) install_starter_pack ;;
            2) continue ;;
            0|"") return ;;
        esac
    done
}
